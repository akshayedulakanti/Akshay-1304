AKSHAY_1304 WEBSITE

Files:
- index.html: website content
- style.css: design and responsive layout
- script.js: small interactive menu and current year
- assets/profile-photo.png: profile image

IMPORTANT BEFORE PUBLISHING:
1. Open index.html and replace YOUR_EMAIL@example.com with a dedicated email address you are comfortable sharing publicly.
2. Do not publish your personal phone number on a public website. Ask a parent/guardian to help choose a safe contact method.
3. Keep all four website files/folders together when uploading.

JavaScript is used here (not Java), because it is the browser language for website interactions.
